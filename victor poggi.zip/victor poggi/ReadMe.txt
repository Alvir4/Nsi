Aujourd’hui moi et mon equipe de devolepement nous avons décidé de construire a partir d’un diagrame de classe un programme python,
qui nous permettras de simuler un jeu de carte une(“bataille”).
Vous pouver retrouver toute les informations sur le dossier ci joint nommé python
et un autre nomé classe. Vous pouvez retrouver mon code sur ma page git hub avec le lien ci dessou:
https://github.com/Alvir4/Nsi

Si ne serait-ce une seul question vous taraude n'ésitez surtout pas a m'envoyer un mail ou a me contacter sur discord 
Je serais disponible et pret a vous repondre dans les plus bref delais 
