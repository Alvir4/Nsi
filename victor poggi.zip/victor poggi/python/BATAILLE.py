
from joueur import*

class Bataille():
    def __init__(self,JeudeCarte,Joueur1,Joueur2): #créer les variables nécessaire a la classe bataille
        self.JeudeCarte = JeudeCarte
        self.Joueur1 = Joueur1
        self.Joueur2 = Joueur2

    def Jouer(self):
        fin = True
        while fin is True:

            carte1 = self.Joueur1.jouerCarte()
            carte2 = self.Joueur2.jouerCarte()
            pli = [carte1,carte2]

            print("La Carte du Joueur", *self.Joueur1.getNom(),"est :", *carte1.getNom(),"de", *carte1.getCouleur())
            print("La Carte du Joueur", *self.Joueur2.getNom(),"est :", *carte2.getNom(),"de", *carte2.getCouleur())

            while carte1.egalite(carte2):
                carte1 = self.Joueur1.jouerCarte()
                carte2 = self.Joueur2.jouerCarte()
                pli.append(carte1)
                pli.append(carte2)
                print("Il y a egalite les joueur rejoue :")
                print("La Carte du Joueur", *self.Joueur1.getNom(), "est :", *carte1.getNom(),"de", *carte1.getCouleur())
                print("La Carte du Joueur", *self.Joueur2.getNom(), "est :", *carte2.getNom(),"de", *carte2.getCouleur())

            if carte1.estSuperieurA(carte2):
                JoueurGagant = self.Joueur1.getNom()
                self.Joueur1.insererMain(pli)

            else:
                JoueurGagant = self.Joueur2.getNom()
                self.Joueur2.insererMain(pli)

            print("Le Joueur", JoueurGagant,"a gagne ce tour")
            print("Nombre de carte en sortie du dernier coup:")
            nbcarte1 = self.Joueur1.getNbCartes()
            nbcarte2 = self.Joueur2.getNbCartes()
            if nbcarte1 != 0 and nbcarte2 != 0:
                print("Nombre de carte de", *self.Joueur1.getNom(), ":",nbcarte1)
                print("Nommbrede Carte de", *self.Joueur2.getNom(), ":",nbcarte2)
            elif nbcarte1 == 0:
                print("Le joueur", *self.Joueur1.getNom(), "à Gagner")
                fin = False
            else:
                print("Le joueur", *self.Joueur2.getNom(), "à Gagner")
                fin = False

def Mise_en_place(nbc,nomJoueur1,nomJoueur2):
    jeu = JeuCartes(nbc)
    jeu.melanger()
    nbParJ = nbc/2
    jeudistri = jeu.distribuerJeu(2,int(nbParJ))
    mainJoueur1 = jeudistri[0]
    mainJoueur2 = jeudistri[1]
    Joueur1 = Joueur(nomJoueur1,nbParJ,mainJoueur1)
    Joueur2 = Joueur(nomJoueur2,nbParJ,mainJoueur2)
    return (jeu,Joueur1,Joueur2)

M = Mise_en_place(int(input("Jeu de 32 ou 52 cartes")), str(input("Nom du premier Joueur ?")), str(input("Nom du Deuxième Joueur ?")))
JDC = M[0]
J1 = M[1]
J2 = M[2]

Game = Bataille(JDC,J1,J2)

Game.Jouer()







