
from JeuDeCarte import *

class Joueur():
    def __init__(self,nom,nbCartes,mainJoueur):#créer les variables nécessaire a la classe joueur
        self.nom = nom
        self.nbCartes = nbCartes
        self.mainJoueur = mainJoueur

    def setmain(self,mainJoueur): # change le contenu de la variable self.mainJoueur
        self.mainJoueur = mainJoueur

    def getmain(self): #renvoi la main du joueur
        return self.mainJoueur

    def getnNom(self): #renvoi le nom du joueur
        return self.nom

    def getNbCartes(self): #renvoi le nombre de carte qu'a le joueur
        self.nbCartes = len(self.mainJoueur)
        return self.nbCartes

    def jouerCarte(self): #permet de jouer une carte
            carte = self.mainJoueur[0]
            self.mainJoueur.remove(carte)
            return carte

    def insererMain(self,carteGagne): #ajoute la carte gangé a la main du joueur
        main = self.mainJoueur
        main += carteGagne
        self.setmain(main)


def testJoueur(nbc): #teste la calsse joueur
    jeu52 = JeuCartes(52)
    jeu52.melanger()
    distribution_3j_4c = jeu52.distribuerJeu(3,nbc)
    mainJoueur1 = distribution_3j_4c[0]
    for c in mainJoueur1:
        print(c.getNom(), "de", c.getCouleur())
    nom1 = "Kevin"
    Joueur1 = Joueur(nom1,nbc,mainJoueur1)
    for c in Joueur1.getmain():
        print(*c.getNom(), *c.getCouleur(), "main du joueur", Joueur1.getNom())
    CarteGagne = Carte("valet", "COEUR")
    Joueur1.insererMain(CarteGagne)
    for c in Joueur1.getmain():
        print(*c.getNom(), *c.getCouleur(), "main du joueur ", Joueur1.getNom(), "aprés insertion du Valet de Coeur")


#testJoueur(4)



