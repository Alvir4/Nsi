
from carte import *
import random

class JeuCartes():
    def __init__(self,nbCartes): # créer les variables nécessaire a la classe JeuCartes
        self.jeu = []
        self.NombreCarte = int(nbCartes)
        self.creerJeu()

    def getTailleJeu(self): #revnoie la taile du jeu de carte
        return self.NombreCarte

    def creerJeu(self): # créer le jeu de carte de 52 ou 32 carte
        tailleJeu = self.getTailleJeu()
        if tailleJeu == 52 :
            print("Le nombre de cartes est 52")
            for i in couleur:
                for j in nom:
                    self.jeu.append(Carte(j,i))
        elif tailleJeu== 32:
            print("Le nombre de cartes est 32")
            for i in couleur :
                for j in nom[5:]:
                    self.jeu.append(Carte(j,i))
        else:
            print("Il n'y a pas le bon nombre de Cartes !")

    def getJeu(self): # renvoi le jeu de carte
        return self.jeu

    def melanger(self): # permet de mélanger le jeu de carte
        random.shuffle(self.jeu)

    def distribuerCarte(self): # permet de distribuer les cartes
        carte = self.jeu[0]
        self.jeu.remove(self.jeu[0])
        return carte

    def distribuerJeu(self, nbJoueurs, nbCartesParJoueur): # distribue les cartes aux joueurs
        mains = []
        for a in range(nbJoueurs):
            mainsdesJoueur = []
            for b in range(nbCartesParJoueur):
                mainsdesJoueur.append(self.distribuerCarte())
            mains.append(mainsdesJoueur)
        return mains


def testJeuDeCarte52 (): # permet de tester la classe JeuCartes si elle est initiallisé pour 52 cartes
    jeu52 = JeuCartes(52)
    jeu52.melanger()
    L = jeu52.getJeu()
    carte = L[2]
    print("Nom :", carte.getNom())
    print("couleur :", carte.getCouleur())
    print("valeur :", carte.getValeur())

    distribution_3j_4c = jeu52.distribuerJeu(3,4)
    for i in range(3):
        print("joueur", i+1,":")
        listeCartes = distribution_3j_4c[i]
        for c in listeCartes :
            print(c.getNom(),"de",c.getCouleur())


def testJeuDeCarte32(): # permet de tester la classe JeuCartes si elle est initiallisé pour 32 cartes
    jeu32 = JeuCartes(32)
    jeu32.melanger()
    L = jeu32.getJeu()
    carte = L[2]
    print("Nom :", carte.getNom())
    print("couleur :", carte.getCouleur())
    print("valeur :", carte.getValeur())

    distribution_3j_4c = jeu32.distribuerJeu(3, 4)
    for i in range(3):
        print("joueur", i + 1, ":")
        listeCartes = distribution_3j_4c[i]
        for c in listeCartes:
            print(c.getNom(), "de", c.getCouleur())

testJeuDeCarte52()
#
print("------------------------------------------")
testJeuDeCarte32()