﻿
##Variables globales
couleur = ('CARREAU', 'COEUR', 'TREFLE', 'PIQUE')
nom = ['2','3','4','5','6','7','8','9','10','Valet','Dame','Roi','As']
valeurs = {'2':2 , '3':3 , '4': 4 , '5':5 , '6':6 , '7':7 , '8':8 , '9':9 , '10':10 , 'Valet':11 , 'Dame':12 , 'Roi':13 , 'As':14}

##Classe carte
class Carte:
    def __init__(self, nom, couleur): #créer les variables nécessaire a la classe carte
        self.nom = nom
        self.couleur = couleur
        self.valeur = valeurs.get(nom)

    def setNom (self, nom): # donne un nom a la carte
        self.nom = nom
        self.valeur = valeurs.get(nom)

    def getNom (self): #renvoi le nom de la carte
        return self.nom

    def getCouleur (self): #revoi la couleur de la carte
        return self.couleur

    def getValeur (self): #renvoi la valeur de la carte
        return self.valeur

    def egalite(self,carte): # teste l'égalité entre deux deux carte
        return self.valeur == carte.valeur

    def estSuperieurA(self,carte): # vérifie si une carte est supérieur a l'autre
        return self.valeur > carte.valeur

    def estinferieurA(self,carte): # vérifie si une carte est inférieur a l'autre
        return self.valeur < carte.valeur


def testcarte (): # permet de tester la classe carte
   ValetCoeur = Carte("valet", "COEUR")
   print("Nom:", ValetCoeur.getNom())
   print("Couleur:", ValetCoeur.getCouleur())
   print("Valeur:", ValetCoeur.getValeur())
   ValetCoeur.setNom("Dame")
   print("Nom modifié :", ValetCoeur.getNom())
   print("valeur modifié :", ValetCoeur.getValeur())

